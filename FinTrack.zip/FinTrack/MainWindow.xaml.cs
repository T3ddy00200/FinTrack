﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using ClosedXML.Excel;
using System.Windows;
using System.Windows.Controls;
using DocumentFormat.OpenXml.Office2013.Word;
using FinTrack.Controls;
using FinTrack.Pages;
using FinTrack.Models;
using FinTrack.Properties;


namespace FinTrack
{
    public partial class MainWindow : Window
    {
        private bool isDarkTheme = true;
        private void ThemeToggleButton_Click(object sender, RoutedEventArgs e)
        {
            var theme = isDarkTheme ? "Themes/LightTheme.xaml" : "Themes/DarkTheme.xaml";
            ApplyTheme(theme);
            isDarkTheme = !isDarkTheme;
        }

        private void ApplyTheme(string themePath)
        {
            var dict = new ResourceDictionary
            {
                Source = new Uri(themePath, UriKind.Relative)
            };

            // Удаляем предыдущую тему (если есть)
            var existing = Application.Current.Resources.MergedDictionaries
                .FirstOrDefault(d => d.Source != null && d.Source.OriginalString.Contains("Theme"));
            if (existing != null)
                Application.Current.Resources.MergedDictionaries.Remove(existing);

            // Добавляем новую
            Application.Current.Resources.MergedDictionaries.Add(dict);
        }

        public MainWindow()
        {
            // Устанавливаем язык до инициализации
            var savedLang = Settings.Default.Language;
            LocalizationManager.SetCulture(savedLang);

            InitializeComponent(); // теперь UI готов

            // Применяем локализацию к MainWindow
            LocalizationManager.LocalizeUI(this);

            // Получаем стартовую панель
            string startPage = Settings.Default.StartPage;

            // 🔥 Обновляем заголовок после инициализации
            SectionTitle.Text = LocalizationManager.GetStringByKey(startPage);

            // Загружаем нужную панель
            MainContentPanel.Content = startPage switch
            {
                "Menu_Home" => new DashboardPanel(),
                "Menu_Debtors" => new DebtorsPanel(),
                "Menu_Invoices" => new InvoicesPanel(),
                "Menu_Reports" => new ReportsPanel(),
                "Menu_Notifications" => new NotificationsPanel(),
                "Menu_Messages" => new MessagesPanel(),
                "Menu_Replies" => new RepliesPanel(),
                "Menu_Security" => new SecurityPanel(),
                "Menu_Settings" => new SettingsPanel(),
                "Menu_Users" => new UsersPanel(),
                _ => new DashboardPanel()
            };
        }




        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            LocalizationManager.LocalizeUI(this);
        }


        private void Menu_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is string tag)
            {
                SectionTitle.Text = LocalizationManager.GetStringByKey(button.Name);

                MainContentPanel.Content = tag switch
                {
                    "Главная" => new DashboardPanel(),
                    "Должники" => new DebtorsPanel(),
                    "Инвойсы" => new InvoicesPanel(),
                    "Отчёты" => new ReportsPanel(),
                    "Уведомления" => new NotificationsPanel(),
                    "Сообщения" => new MessagesPanel(),
                    "Ответы" => new RepliesPanel(),
                    "Безопасность" => new SecurityPanel(),
                    "Настройки" => new SettingsPanel(),
                    "Пользователи" => new UsersPanel(),
                    _ => null
                };
            }
        }


    }
}
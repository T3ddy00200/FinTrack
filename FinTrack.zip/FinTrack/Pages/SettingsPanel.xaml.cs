﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using FinTrack.Models;
using FinTrack.Properties;


namespace FinTrack.Pages
{
    public partial class SettingsPanel : UserControl
    {
        public SettingsPanel()
        {
            InitializeComponent();
        }
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            string savedLang = Settings.Default.Language;

            foreach (ComboBoxItem item in LanguageSelector.Items)
            {
                if (item.Tag is string lang && lang == savedLang)
                {
                    item.IsSelected = true;
                    break;
                }
            }
            string savedPage = Settings.Default.StartPage;

            foreach (ComboBoxItem item in StartPageSelector.Items)
            {
                if (item.Tag is string tag && tag == savedPage)
                {
                    item.IsSelected = true;
                    break;
                }
            }


        }


        private void LanguageSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (LanguageSelector.SelectedItem is ComboBoxItem selectedItem && selectedItem.Tag is string selectedLang)
            {
                Settings.Default.Language = selectedLang;
                Settings.Default.Save();
                LocalizationManager.SetCulture(selectedLang);
                LocalizationManager.LocalizeUI(Window.GetWindow(this));
            }
        }

        private void StartPageSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (StartPageSelector.SelectedItem is ComboBoxItem selectedItem && selectedItem.Tag is string selectedTag)
            {
                Settings.Default.StartPage = selectedTag; // сохраняем "Menu_Home" и т.п.
                Settings.Default.Save();
            }
        }



    }
}